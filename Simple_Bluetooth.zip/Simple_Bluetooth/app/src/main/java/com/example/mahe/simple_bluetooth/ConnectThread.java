package com.example.mahe.simple_bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.widget.Toast;

import java.io.IOException;
import java.util.UUID;

/**
 * Created by MAHE on 2/2/2017.
 */
public class ConnectThread extends Thread {

    private static Context context;
    private BluetoothSocket socket;
    private BluetoothDevice device;
    BluetoothAdapter ctbAdapter;

    public ConnectThread(BluetoothDevice device, Context c , BluetoothAdapter bAdapter){

        context = c;
        ctbAdapter = bAdapter;

        try{

            socket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));

        }catch(IOException io){

            Toast.makeText(context,"ERROR IN CREATING SOCKET",Toast.LENGTH_SHORT).show();

        }

    }

    public void run(){

        ctbAdapter.cancelDiscovery();

        try{
            socket.connect();
        } catch (IOException e) {

            try{
                socket.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

            return;

        }

    }

    public BluetoothSocket returnSocket(){

        return socket;

    }

    public void cancel(){
        try{
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
