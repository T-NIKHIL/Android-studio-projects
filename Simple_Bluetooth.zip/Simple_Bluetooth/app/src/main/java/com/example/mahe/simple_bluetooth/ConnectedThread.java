package com.example.mahe.simple_bluetooth;

import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by MAHE on 2/2/2017.
 */
public class ConnectedThread extends Thread {

    OutputStream outputStream;

    public ConnectedThread (BluetoothSocket socket){

        try{
            outputStream = socket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void write(Byte bytes){

        try{
            outputStream.write(bytes);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}
