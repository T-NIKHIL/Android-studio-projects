package com.example.mahe.simple_bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.os.ParcelUuid;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

import static java.lang.System.exit;

public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener{

    int REQUEST_ENABLE_BT = 1;

    TextView rollText;
    SeekBar seekBar1;
    Button liftButton;
    Button landButton;
    ListView listView;
    BluetoothAdapter bAdapter;
    BluetoothDevice device;

    ConnectThread connectThread;
    ConnectedThread connectedThread;
    Context c;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rollText = (TextView) findViewById(R.id.rolltext);
        seekBar1 = (SeekBar) findViewById(R.id.seek1);
        liftButton = (Button) findViewById(R.id.LIFT);
        landButton = (Button) findViewById(R.id.LAND);
        listView = (ListView) findViewById(R.id.list1);

        seekBar1.setOnSeekBarChangeListener(this);

        bAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bAdapter == null) {
            Toast.makeText(getApplicationContext(), "SORRY DEVICE DOES NOT SUPPORT BLUETOOTH", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            if (!bAdapter.isEnabled()) {
                Intent enablebtIntent = new Intent(bAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult( enablebtIntent, REQUEST_ENABLE_BT);
            }
        }

    }

    public void onActivityResult( int requestCode , int resultCode ){
        if(requestCode == REQUEST_ENABLE_BT){
            if(resultCode == RESULT_OK){
                queryPairedDevices();
            }else{
                Toast.makeText(getApplicationContext(),"PROBLEM IN ENABLING BLUETOOTH",Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void queryPairedDevices() {
        final Set<BluetoothDevice> pairedDevices = bAdapter.getBondedDevices();

        if(pairedDevices.size() == 0){
            Toast.makeText(getApplicationContext() , "NO PAIRED DEVICES FOUND", Toast.LENGTH_SHORT).show();
        }

        if(pairedDevices.size()>0) {
            ArrayList list = new ArrayList();
            for (BluetoothDevice bt : pairedDevices) list.add(bt.getName());

            ArrayAdapter bluetoothAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);

            listView.setAdapter(bluetoothAdapter);
        }

       /* listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                connectThread = new ConnectThread(device,c,bAdapter);
                connectThread.run();

                connectedThread = new ConnectedThread(connectThread.returnSocket());

               // connectedThread.write(Byte.valueOf(String.valueOf(editText.getText())));


            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(getApplicationContext(),device.describeContents() + device.getBondState(),Toast.LENGTH_SHORT).show();

                return true;
            }
        });*/

    }


    protected void onDestroy() {
        super.onDestroy();
        bAdapter.disable();
        Toast.makeText(getApplicationContext(),"APP IS CLOSING",Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onProgressChanged(SeekBar seekBar, final int progress, boolean fromUser) {

        Thread t = new Thread(){

            public void run(){
                try{
                    while(!isInterrupted()){
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateTextView(progress);
                            }
                        });
                    }
                }catch(InterruptedException e){

                }
            }

        };

        t.start();

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    public void updateTextView(int progress){
        rollText.setText(progress);

    }
}

