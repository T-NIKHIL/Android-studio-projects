package com.example.nikhilt.wifi_application;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button enableBtn;
    Button disableBtn;
    Button searchBtn;

    TextView textView;

    ListView listView;
    ArrayList<String> wifiList;
    List<ScanResult> list;

    WifiManager wifiManager;
    WifiInfo wifiInfo;
    WifiScanReceiver wifiScanReceiver;


    StringBuilder stringBuilder;
    String display;

    Context context1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.context1 = getApplicationContext();

        enableBtn = (Button) findViewById(R.id.enableBtn);
        disableBtn = (Button) findViewById(R.id.disableBtn);
        searchBtn = (Button) findViewById(R.id.searchBtn);
        textView = (TextView) findViewById(R.id.info);
        listView = (ListView) findViewById(R.id.list);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        enableBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wifiManager.setWifiEnabled(true);
            }
        });

        disableBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wifiManager.setWifiEnabled(false);
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(wifiManager.isWifiEnabled()) {

                    wifiScanReceiver = new WifiScanReceiver();
                    registerReceiver(wifiScanReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
                    wifiManager.startScan();
                    Toast.makeText(getApplicationContext(), "STARTING SCAN ...", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(getApplicationContext(),"ENABLE WiFi",Toast.LENGTH_SHORT).show();
                }

                wifiInfo = wifiManager.getConnectionInfo();
                display = "MAC ADDR : " + wifiInfo.getMacAddress() + "\n" + "SPEED : " + wifiInfo.getLinkSpeed() + "\n" +  "IP ADDR : " + wifiInfo.getIpAddress();
                textView.setText(display);

            }
        });
    }

    public class WifiScanReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context , Intent intent) {

            list = wifiManager.getScanResults();
            wifiList = new ArrayList<String>();

            for(int i = 0 ; i < list.size() ; i++ ){
            }


        }
    }

    public void onPause(){
        super.onPause();
        unregisterReceiver(wifiScanReceiver);
    }

    public void onDestroy(){
        super.onDestroy();
        Toast.makeText(getApplicationContext(),"APP IS CLOSING ..",Toast.LENGTH_SHORT).show();
    }

}
