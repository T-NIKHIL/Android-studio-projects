package com.example.nikhilt.hc_05;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {

    ConnectThread connectThread;
    ConnectedThread connectedThread;

    Button disconnectButton;
    Button connectButton;
    Button statusButton;
    Button dataButton;
    TextView pitchValue;
    TextView rollValue;
    TextView yawValue;
    TextView tempValue;
    TextView timeValue;
    TextView text3;

    BluetoothAdapter bAdapter;
    BluetoothDevice reqDevice = null;

    StringBuilder recDataString;

    static Handler h;

    int found = 0;
    final int RECEIVE_MESSAGE = 1;
    int already_connected = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connectButton = (Button) findViewById(R.id.connectButton);
        disconnectButton = (Button) findViewById(R.id.disconnectButton);
        statusButton = (Button) findViewById(R.id.status);
        dataButton = (Button) findViewById(R.id.data);
        pitchValue = (TextView) findViewById(R.id.pitchValue);
        rollValue = (TextView) findViewById(R.id.rollValue);
        yawValue = (TextView) findViewById(R.id.yawValue);
        tempValue = (TextView) findViewById(R.id.tempValue);
        timeValue = (TextView) findViewById(R.id.timeValue);

        text3 = (TextView) findViewById(R.id.text3);

        recDataString = new StringBuilder();

        bAdapter = BluetoothAdapter.getDefaultAdapter();

        h = new Handler(){
            public void handleMessage(Message msg) {

                switch (msg.what) {

                    case RECEIVE_MESSAGE:
                        String readMessage = (String) msg.obj;
                        //String strIncom = new String(readBuf,0,msg.arg1);
                        //recDataString.setLength(0);
                        recDataString.append(readMessage);

                        int endOfLineIndex = recDataString.indexOf("~");

                        if(endOfLineIndex > 0){

                            String sbprint = recDataString.substring(0,endOfLineIndex);
                            int dataLength = sbprint.length();
                            text3.setText("STRING LT = " + String.valueOf(dataLength));

                            if(recDataString.charAt(0) == '#'){

                                int endOfLineIndex1 = recDataString.indexOf("p");
                                String pitch = recDataString.substring(1, endOfLineIndex1);
                                pitchValue.setText(pitch);
                                int endOfLineIndex2 = recDataString.indexOf("r");
                                String roll = recDataString.substring(endOfLineIndex1 + 1, endOfLineIndex2);
                                rollValue.setText(roll);
                                int endOfLineIndex3 = recDataString.indexOf("y");
                                String yaw = recDataString.substring(endOfLineIndex2 + 1, endOfLineIndex3);
                                yawValue.setText(yaw);
                                int endOfLineIndex4 = recDataString.indexOf("T");
                                String temp = recDataString.substring(endOfLineIndex3 + 1, endOfLineIndex4);
                                tempValue.setText(temp);
                                int endOfLineIndex5 = recDataString.indexOf("t");
                                String time = recDataString.substring(endOfLineIndex4 + 1, endOfLineIndex5);
                                timeValue.setText(time);

                            }

                            recDataString.delete(0,recDataString.length());
                            //sbprint = " ";
                            //recDataString.delete(0,recDataString.length());
                            //heightValue.setText(sbprint);
                        }
                        break;
                }
            }
        };


        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(found == 1 && bAdapter.isEnabled()) {
                    if(already_connected == 0)
                        startConnection();
                    else
                        Toast.makeText(getApplicationContext(),"ALREADY CONNECTED",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Searching for HC-05...",Toast.LENGTH_SHORT).show();
                }

            }
        });

        disconnectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(connectThread.status().equals("connected") && bAdapter.isEnabled()) {
                    connectThread.cancel();
                    already_connected=0;
                    Toast.makeText(getApplicationContext(),"DISCONNECTED",Toast.LENGTH_SHORT).show();
                }else if(connectThread.status().equals("disconnected")){
                    Toast.makeText(getApplicationContext(),"ENABLE CONNECTION",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Waiting .. to establish conn",Toast.LENGTH_SHORT).show();
                }

            }
        });

        statusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String toast = connectThread.status();
                Toast.makeText(getApplicationContext(), toast, Toast.LENGTH_SHORT).show();
            }
        });

        dataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bAdapter.isEnabled() && connectThread.status().equals("connected"))
                    manageConnection();
                else if(connectThread.status().equals("disconnected"))
                    Toast.makeText(getApplicationContext(),"CONNECT",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(),"Waiting .. to establish conn",Toast.LENGTH_SHORT).show();
            }
        });

        if (bAdapter == null) {
            Toast.makeText(getApplicationContext(), "BLUETOOTH NOT SUPPORTED", Toast.LENGTH_SHORT).show();
        }

    }

    public void onStart(){
        super.onStart();
        if (bAdapter.isEnabled()) {
            queryPairedDevices();
        } else {
            Intent enableBt = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBt,1);
        }
    }

    public void onActivityResult(int requestCode,int resultCode,Intent data){

        if(resultCode == RESULT_OK){
            if(requestCode == 1){
                queryPairedDevices();
            }
        }else{
            Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_SHORT).show();
        }
    }

    public void queryPairedDevices() {
        final Set<BluetoothDevice> pairedDevices = bAdapter.getBondedDevices();

        if (pairedDevices.size() == 0) {
            Toast.makeText(getApplicationContext(), "NO PAIRED DEVICES FOUND", Toast.LENGTH_SHORT).show();
        }

        if (pairedDevices.size() > 0) {

            for (BluetoothDevice bt : pairedDevices) {

                if (bt.getName().equals("DARTHB")) {
                    reqDevice = bt;
                    found = 1;
                    Toast.makeText(getApplicationContext(), "HC-05 FOUND", Toast.LENGTH_SHORT).show();
                }

            }
        }

        if(found == 0){
            Toast.makeText(getApplicationContext(),"HC-05 NOT FOUND",Toast.LENGTH_SHORT).show();
        }

    }

    public void startConnection() {
        connectThread = new ConnectThread( reqDevice );
        connectThread.start();
        disconnectButton.setEnabled(true);
        dataButton.setEnabled(true);
        statusButton.setEnabled(true);
    }

    public void manageConnection(){
        connectedThread = new ConnectedThread(connectThread.returnSocket());
        connectedThread.start();
    }

    public void onDestroy(){
        super.onDestroy();
        if(connectThread.status().equals("connected") && bAdapter.isEnabled()) {
            connectThread.cancel();
        }
        bAdapter.disable();
        Toast.makeText(getApplicationContext(),"LEAVING APP",Toast.LENGTH_SHORT).show();

    }

    private class ConnectThread extends Thread {

        String connected = "not-connected";
        BluetoothDevice bDevice1;
        BluetoothSocket socket;

        private ConnectThread(BluetoothDevice device){
            bDevice1 = device;
            try{
                socket = bDevice1.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        public void run() {

            try {
                socket.connect();
                connected = "connected";
                already_connected = 1;

            } catch (IOException e) {
                e.printStackTrace();

                connected = "disconnected";

                try {
                    socket.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

            }
        }

        private String status(){
            return connected;
        }

        private BluetoothSocket returnSocket(){
            return socket;
        }

        private void cancel(){
            try{
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            connected = "disconnected";
        }
    }



    private class ConnectedThread extends Thread {
        private BluetoothSocket mmSocket;
        InputStream mmInStream;
        byte[] mmBuffer;

        private ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;

            try {
                mmInStream = mmSocket.getInputStream();
            } catch (IOException e) {
                String TAG = "error";
                Log.e(TAG, "Error occurred when creating input stream", e);
            }
        }

        public void run() {

            byte[] mmBuffer = new byte[1024];
            int numBytes;

            while (true) {
                try {

                    numBytes = mmInStream.read(mmBuffer);
                    String readMessage = new String(mmBuffer , 0, numBytes);
                    h.obtainMessage(RECEIVE_MESSAGE, numBytes, -1, readMessage).sendToTarget();

                } catch (IOException e) {
                    String TAG = "error";
                    Log.d(TAG, "Input stream was disconnected", e);
                    break;
                }
            }
        }

    }

}
