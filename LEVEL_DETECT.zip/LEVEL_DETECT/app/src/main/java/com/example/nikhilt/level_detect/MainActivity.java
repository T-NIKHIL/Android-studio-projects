package com.example.nikhilt.level_detect;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity  {

    int REQUEST_ENABLE_BT = 1;

    private StringBuilder dataString = new StringBuilder();

    public int statusReceived;

    ConnectThread connectThread;

    TextView textView;
    ListView listView;

    BluetoothAdapter bAdapter;

    BluetoothDevice reqDevice;

    Handler handler;

    ArrayList<BluetoothDevice> bList;
    ArrayList<String> infoList;


    private interface MessageConstants{
        int MESSAGE_READ = 0;
        int MESSAGE_WRITE = 1;
        int MESSAGE_TOAST = 2;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.height);
        listView = (ListView) findViewById(R.id.paired_device_list);

        handler = new Handler(){

            public void handleMessage(Message inputMessage){

                if(inputMessage.what == MessageConstants.MESSAGE_READ){

                    String readMsg = (String) inputMessage.obj;
                    dataString.append(readMsg);
                    int endOfLineIndex = dataString.indexOf("~");
                    if(endOfLineIndex>0){

                        if(dataString.charAt(0) == '#'){

                            String text = dataString.substring(1,5);
                            textView.setText(text);

                        }
                        dataString.delete(0,dataString.length());
                    }
                }

                if(inputMessage.what == MessageConstants.MESSAGE_WRITE){
                    //DO THE NECESSARY
                }

                if(inputMessage.what == MessageConstants.MESSAGE_TOAST){
                    //DO THE NECESSARY
                }

            }
        };

    }

    public void onStart(){
        super.onStart();

        bAdapter = BluetoothAdapter.getDefaultAdapter();

        if(bAdapter == null){
            Toast.makeText(getApplicationContext(),"DEVICE DOES NOT SUPPORT BLUETOOTH",Toast.LENGTH_SHORT).show();
            finish();
        }else{
            if(!bAdapter.isEnabled()){
                Intent enableBt = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBt,REQUEST_ENABLE_BT);
            }else{
                queryPairedDevices();
            }
        }
    }



    public void onActivityResult(int requestCode, int resultCode , Intent enableBt){
        if (requestCode == REQUEST_ENABLE_BT) {
            if(resultCode == RESULT_OK) {
                queryPairedDevices();
            }else{
                Toast.makeText(getApplicationContext(),"UNABLE TO ENABLE BT",Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String getBTMajorDeviceClass(int major){
        switch(major){
            case BluetoothClass.Device.Major.AUDIO_VIDEO:
                return "AUDIO_VIDEO";
            case BluetoothClass.Device.Major.COMPUTER:
                return "COMPUTER";
            case BluetoothClass.Device.Major.HEALTH:
                return "HEALTH";
            case BluetoothClass.Device.Major.IMAGING:
                return "IMAGING";
            case BluetoothClass.Device.Major.MISC:
                return "MISC";
            case BluetoothClass.Device.Major.NETWORKING:
                return "NETWORKING";
            case BluetoothClass.Device.Major.PERIPHERAL:
                return "PERIPHERAL";
            case BluetoothClass.Device.Major.PHONE:
                return "PHONE";
            case BluetoothClass.Device.Major.TOY:
                return "TOY";
            case BluetoothClass.Device.Major.UNCATEGORIZED:
                return "UNCATEGORIZED";
            case BluetoothClass.Device.Major.WEARABLE:
                return "AUDIO_VIDEO";
            default: return "unknown!";
        }
    }

    public void queryPairedDevices(){

        final Set<BluetoothDevice> pairedDevices = bAdapter.getBondedDevices();
        bList = new ArrayList<BluetoothDevice>();
        infoList = new ArrayList<String>();

        for(BluetoothDevice btDevice : pairedDevices ){

            String deviceBTMajorClass = getBTMajorDeviceClass(btDevice.getBluetoothClass().getMajorDeviceClass());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                bList.add(btDevice);
                infoList.add(btDevice.getName() + "\n" + btDevice.getAddress() + "\n" + deviceBTMajorClass);
            }
            if(btDevice.getName().equals("HC-05")){
                Toast.makeText(getApplicationContext(),"HC-05 FOUND",Toast.LENGTH_SHORT).show();
                reqDevice = btDevice;
            }

        }

        listView.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,infoList));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(getApplicationContext(),"ITEM CLICKED",Toast.LENGTH_SHORT).show();
                connectThread = new ConnectThread(reqDevice,bAdapter);


            }

        });
    }

    private class ConnectThread extends Thread {

        Context context;
        private BluetoothSocket socket;
        private BluetoothDevice bDevice1;
        private BluetoothAdapter bAdapter1;
        public int STATUS = 1;

        public ConnectThread(BluetoothDevice bDevice , BluetoothAdapter bAdapter ){

            bDevice1 = bDevice;
            bAdapter1 = bAdapter;

            try{
                socket = bDevice1.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
            }catch(IOException io){
                Toast.makeText(context,"SOCKET CREATION FAILURE",Toast.LENGTH_SHORT).show();
            }

        }

        public void run(){

            bAdapter1.cancelDiscovery();

            try{
                socket.connect();
            } catch (IOException e) {
                STATUS = 0;
                try{
                    socket.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                return;
            }

            Toast.makeText(context,"HELLO",Toast.LENGTH_SHORT).show();

            if(STATUS == 0){
                Toast.makeText(context, "CONNECTION FAILED",Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(context,"CONNECTION SUCCESS",Toast.LENGTH_SHORT).show();
            }
        }

        public int checkStatus(){

            return STATUS;

        }


        public BluetoothSocket bSocket(){

            return socket;
        }



        public void cancel(){
            try{
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }




    public void onDestroy(){
        super.onDestroy();
        bAdapter.disable();
        Toast.makeText(getApplicationContext(),"APP IS CLOSING",Toast.LENGTH_SHORT).show();
    }


}
